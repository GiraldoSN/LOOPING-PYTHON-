t = int(input("Masukkan angka: "))
for i in range(1,t+1):
    print((t-i+1)* "*")