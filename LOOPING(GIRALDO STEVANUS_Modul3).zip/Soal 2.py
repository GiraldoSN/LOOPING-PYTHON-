print ('Ini Adalah Sebuah Kalkulator Dengan Looping')
print ('Pilih = 1 (Penjumlahan),2 (Pengurangan),3 (Perkalian),4 (Pembagian)')
angka1 = float(input('Masukkan Angka Pertama Anda : '))
angka2 = float(input('Masukkan Angka Kedua Anda : '))

x  = input('Pilih Menu Anda : ')
while True :

    if x == '1' :
        hasil = angka1 + angka2
        print('Nilai Penjumlahan Anda : ', hasil)
        break
    elif x == '2' :
        hasil = angka1-angka2
        print('Nilai Pengurangan Anda : ', hasil)
        break
    elif x == '3' :
        hasil = angka1*angka2
        print('Nilai Perkalian Anda : ', hasil)
        break
    elif x == '4' :
        hasil = angka1 / angka2
        print('Nilai Pembagian Anda : ', hasil)
        break
    else:
        print ('Menu Yang Anda Masukkan Salah')
        break
